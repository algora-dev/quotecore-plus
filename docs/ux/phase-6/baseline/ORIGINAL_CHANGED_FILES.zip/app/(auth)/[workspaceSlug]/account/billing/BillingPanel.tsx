'use client';

/**
 * Billing tab - tier picker with View modals.
 *
 * Three jobs:
 *   1. Show the company's current plan + status + key dates (next
 *      period end, payment-failure timer).
 *   2. Render a card for every selectable plan; Stripe plans go through
 *      Checkout. Coming-soon plans render as greyed-out cards.
 *   3. Provide a "View" modal per plan with the full feature breakdown.
 *      The modal has two buttons: Close + Purchase (which kicks off the
 *      same flow as the card's primary button).
 */

import { useState, useTransition, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

import {
  createCheckoutSession,
  createCustomerPortalSession,
  changePlan,
  type BillingActionResult,
} from './actions';

export interface BillingPlanInfo {
  code: string;
  displayName: string;
  /** Tier ordering. Higher = more expensive tier; drives upgrade/downgrade
   *  direction in the in-app plan switch. */
  sortOrder: number;
  priceCentsMonthly: number;
  /**
   * Original (pre-discount) monthly price in cents. Renders as a
   * strikethrough next to the live price when set and strictly greater
   * than priceCentsMonthly. NULL = no strikethrough.
   */
  priceCentsMonthlyOriginal: number | null;
  monthlyQuoteLimit: number;
  storageLimitBytes: number;
  componentLimit: number | null;
  flashingLimit: number | null;
  monthlyMaterialOrderLimit: number | null;
  monthlyInvoiceLimit: number | null;
  monthlyAiTokens: number | null;
  /**
   * AI document parsing limit per billing period (quote/order/invoice
   * upload + text prompt). NULL = unlimited. 0 = not included.
   */
  monthlyAiParseLimit: number | null;
  /**
   * AI Assist scan points per billing period (roofing takeoff feature).
   * NULL = not included in this plan.
   */
  aiAssistPointsLimit: number | null;
  includedSeats: number;
  features: {
    digital_takeoff: boolean;
    flashings: boolean;
    material_orders: boolean;
    followups: boolean;
    email_send: boolean;
    activity_card: boolean;
    invoices: boolean;
    message_center: boolean;
  };
  tagline: string | null;
  featureBlurbs: string[];
  /**
   * Coming-soon tiers render as greyed-out cards. View modal still works
   * but the primary action button is disabled.
   */
  comingSoon: boolean;
  /**
   * Stripe price configured for this environment. False for tiers we
   * haven't seeded yet. Drives the
   * "Choose plan" button enabled state.
   */
  hasStripePrice: boolean;
}

export interface BillingPanelProps {
  /** Current effective plan (could differ from purchased during dunning). */
  effectivePlanCode: string;
  /** What the user purchased (drives portal eligibility). */
  purchasedPlanCode: string;
  /** Subscription lifecycle state. */
  subscriptionStatus: string;
  /** Whether the company already has a Stripe customer record. */
  hasStripeCustomer: boolean;
  /** Whether the company has an ACTIVE Stripe subscription (drives plan-switch gating). */
  hasActiveSubscription: boolean;
  /** Current period end (ISO) when subscription is active. */
  currentPeriodEnd: string | null;
  /**
   * True when the user has scheduled cancellation at period end via the
   * Stripe portal. Combined with `cancelAt` to render the “Cancelled -
   * ending {date}” secondary pill on the current-plan card.
   */
  cancelAtPeriodEnd: boolean;
  /**
   * Explicit cancellation timestamp (ISO). Falls back to currentPeriodEnd
   * when cancelAtPeriodEnd is true.
   */
  cancelAt: string | null;
  /** First payment failure (ISO) - drives the past_due banner. */
  firstPaymentFailureAt: string | null;
  /** Storage usage. */
  storageUsedBytes: number;
  storageLimitBytes: number;
  /** All available plans (including coming-soon). */
  plans: BillingPlanInfo[];
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(0)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(0)} GB`;
}

function formatPrice(cents: number): string {
  if (cents === 0) return 'Free';
  return `$${(cents / 100).toFixed(0)}/mo`;
}

/**
 * Optional strikethrough "before" price. Returns null when there's no
 * meaningful discount to render. Centralised so the card and modal stay
 * in sync on the threshold logic.
 */
function formatOriginalPrice(
  original: number | null,
  current: number,
): string | null {
  if (original === null) return null;
  if (original <= current) return null;
  return `$${(original / 100).toFixed(0)}`;
}

function formatDate(iso: string | null): string {
  if (!iso) return '-';
  return new Date(iso).toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

/**
 * Format a numeric cap with NULL = "Unlimited" and 0 = "-". Used inside
 * the View modal for component / flashing / order caps.
 */
function formatCap(value: number | null, suffix = ''): string {
  if (value === null) return 'Unlimited';
  if (value === 0) return '-';
  return `${value}${suffix}`;
}

export function BillingPanel(props: BillingPanelProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [pending, startTransition] = useTransition();
  const [activePlan, setActivePlan] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [viewPlan, setViewPlan] = useState<BillingPlanInfo | null>(null);

  const checkoutFlag = searchParams.get('checkout');
  const changeFlag = searchParams.get('change');

  function handleResult(result: BillingActionResult) {
    if (result.ok) {
      window.location.href = result.url;
      return;
    }
    setError(result.message);
  }

  /**
   * Single dispatch point for plan-card and modal-Purchase buttons. All
   * plans go through Stripe checkout.
   */
  function onChoose(plan: BillingPlanInfo) {
    if (plan.comingSoon) return;

    setError(null);
    setActivePlan(plan.code);
    startTransition(async () => {
      const result = await createCheckoutSession(plan.code);
      handleResult(result);
      setActivePlan(null);
      setViewPlan(null);
    });
  }

  function onManage() {
    setError(null);
    startTransition(async () => {
      const result = await createCustomerPortalSession();
      handleResult(result);
    });
  }

  function dismissBanner() {
    const params = new URLSearchParams(searchParams);
    params.delete('checkout');
    params.delete('session_id');
    params.delete('change');
    const qs = params.toString();
    router.replace(qs ? `?${qs}` : '?', { scroll: false });
  }

  // Esc closes the View modal.
  useEffect(() => {
    if (!viewPlan) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === 'Escape') setViewPlan(null);
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [viewPlan]);

  // ---- Status badge ----
  const statusBadgeClass: Record<string, string> = {
    trialing: 'bg-blue-100 text-blue-700',
    active: 'bg-emerald-100 text-emerald-700',
    past_due: 'bg-amber-100 text-amber-800',
    grace: 'bg-amber-100 text-amber-800',
    pending_data_purge: 'bg-red-100 text-red-700',
    disputed: 'bg-purple-100 text-purple-700',
    cancellation_pending: 'bg-slate-100 text-slate-700',
    suspended: 'bg-red-100 text-red-700',
    canceled: 'bg-slate-200 text-slate-700',
  };
  const statusClass = statusBadgeClass[props.subscriptionStatus] || 'bg-slate-100 text-slate-700';

  // Pill label + colour (smoke #9, 2026-05-19). The raw
  // subscription_status is too internal for a user-facing pill; humanise
  // it. ('trialing' remains a valid legacy DB status - comped accounts.)
  const statusPillLabel: string = props.subscriptionStatus.replace(/_/g, ' ');
  const statusPillClass: string = statusClass;

  const storagePct = props.storageLimitBytes
    ? Math.min(100, Math.round((props.storageUsedBytes / props.storageLimitBytes) * 100))
    : 0;

  // “Cancelled - ending {date}” secondary pill. Renders alongside the
  // primary status pill when the user has scheduled cancellation at the
  // end of their current period via the Stripe Portal.
  const cancelDateIso = props.cancelAt ?? props.currentPeriodEnd;
  const showCancellingPill =
    (props.cancelAtPeriodEnd || (props.cancelAt && new Date(props.cancelAt).getTime() > Date.now()))
    && cancelDateIso !== null
    && props.subscriptionStatus !== 'canceled';

  // In-app plan change: the target plan the user has clicked to switch to
  // (active subscriber). Drives the confirm modal; null = closed.
  const [changeTarget, setChangeTarget] = useState<BillingPlanInfo | null>(null);

  // sort_order of the plan the user is CURRENTLY on, to label the switch as an
  // upgrade or a downgrade in the confirm modal. Uses PURCHASED plan for Stripe
  // switch direction (you switch FROM what you pay for).
  const currentSortOrder =
    props.plans.find((p) => p.code === props.purchasedPlanCode)?.sortOrder ?? null;

  // ---- Upgrade/downgrade label for current plan card ----
  // When effectivePlanCode differs from purchasedPlanCode (admin override,
  // dunning downgrade, etc.) show whether the user was upgraded or downgraded.
  // Green for upgrade, amber for downgrade.
  const effectiveSortOrder =
    props.plans.find((p) => p.code === props.effectivePlanCode)?.sortOrder ?? null;
  const purchasedSortOrder =
    props.plans.find((p) => p.code === props.purchasedPlanCode)?.sortOrder ?? null;
  const showPlanDelta =
    props.effectivePlanCode !== props.purchasedPlanCode
    && effectiveSortOrder != null
    && purchasedSortOrder != null;
  const isEffectiveUpgrade =
    effectiveSortOrder != null && purchasedSortOrder != null
      ? effectiveSortOrder > purchasedSortOrder
      : false;
  const isUpgradeTarget =
    changeTarget && currentSortOrder != null
      ? changeTarget.sortOrder > currentSortOrder
      : true;

  function onConfirmChange(plan: BillingPlanInfo) {
    setError(null);
    setActivePlan(plan.code);
    startTransition(async () => {
      const result = await changePlan(plan.code);
      handleResult(result);
      setActivePlan(null);
      setChangeTarget(null);
    });
  }

  return (
    <div className="space-y-6">
      {/* Stripe redirect banners */}
      {changeFlag === 'upgraded' && (
        <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-2 md:p-4 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-emerald-900">Plan upgraded.</p>
            <p className="text-xs text-emerald-700 mt-1">
              Your new plan is active. The card on file is charged the prorated difference; your plan card updates within a few seconds once Stripe confirms.
            </p>
          </div>
          <button onClick={dismissBanner} className="text-xs text-emerald-700 hover:underline">
            Dismiss
          </button>
        </div>
      )}
      {changeFlag === 'downgrade_scheduled' && (
        <div className="rounded-lg border border-blue-200 bg-blue-50 p-2 md:p-4 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-blue-900">Plan change scheduled.</p>
            <p className="text-xs text-blue-700 mt-1">
              You keep your current plan until the end of this billing period, then it switches automatically. No charge now.
            </p>
          </div>
          <button onClick={dismissBanner} className="text-xs text-blue-700 hover:underline">
            Dismiss
          </button>
        </div>
      )}
      {checkoutFlag === 'success' && (
        <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-2 md:p-4 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-emerald-900">Subscription started.</p>
            <p className="text-xs text-emerald-700 mt-1">
              Your plan will update within a few seconds once Stripe confirms the payment.
            </p>
          </div>
          <button onClick={dismissBanner} className="text-xs text-emerald-700 hover:underline">
            Dismiss
          </button>
        </div>
      )}
      {checkoutFlag === 'canceled' && (
        <div className="rounded-lg border border-slate-200 bg-slate-50 p-2 md:p-4 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-slate-900">Checkout canceled.</p>
            <p className="text-xs text-slate-600 mt-1">No changes were made to your subscription.</p>
          </div>
          <button onClick={dismissBanner} className="text-xs text-slate-700 hover:underline">
            Dismiss
          </button>
        </div>
      )}
      {/* Current plan card */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-2 md:p-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-wide text-slate-500 font-semibold">Current plan</p>
            <h3 className="text-lg font-semibold text-slate-900 mt-1 capitalize">
              {props.effectivePlanCode.replace(/_/g, ' ')}
              {showPlanDelta && (
                <span
                  className={`ml-2 text-sm font-normal ${
                    isEffectiveUpgrade ? 'text-emerald-600' : 'text-amber-700'
                  }`}
                >
                  ({isEffectiveUpgrade ? 'upgraded' : 'downgraded'} from{' '}
                  {props.purchasedPlanCode.replace(/_/g, ' ')})
                </span>
              )}
            </h3>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <span
                className={`inline-block text-xs px-2 py-0.5 rounded-full font-medium ${statusPillClass}`}
              >
                {statusPillLabel}
              </span>
              {showCancellingPill && (
                <span className="inline-block text-xs px-2 py-0.5 rounded-full font-medium bg-amber-100 text-amber-800">
                  Cancelling - ending {formatDate(cancelDateIso)}
                </span>
              )}
            </div>
          </div>
          {props.hasStripeCustomer && (
            <button
              type="button"
              onClick={onManage}
              disabled={pending}
              title="Cancel, swap plan, update card, or view invoices"
              className="px-4 py-2 text-sm font-medium rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 disabled:opacity-50 min-h-[44px]"
            >
              Manage subscription
            </button>
          )}
        </div>

        <dl className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
          {props.currentPeriodEnd && (
            <div>
              <dt className="text-xs text-slate-500">Next billing</dt>
              <dd className="font-medium text-slate-900">{formatDate(props.currentPeriodEnd)}</dd>
            </div>
          )}
          {props.firstPaymentFailureAt && (
            <div>
              <dt className="text-xs text-slate-500">First payment failure</dt>
              <dd className="font-medium text-amber-800">{formatDate(props.firstPaymentFailureAt)}</dd>
            </div>
          )}
          <div>
            <dt className="text-xs text-slate-500">Storage</dt>
            <dd className="font-medium text-slate-900">
              {formatBytes(props.storageUsedBytes)} of {formatBytes(props.storageLimitBytes)}
            </dd>
            <div className="mt-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full ${storagePct >= 90 ? 'bg-amber-500' : 'bg-orange-500'}`}
                style={{ width: `${storagePct}%` }}
              />
            </div>
          </div>
        </dl>
      </div>

      {/* Plan grid */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-2 md:p-6">
        <h3 className="text-base font-semibold text-slate-900">Plans</h3>
        <p className="text-sm text-slate-500 mt-1">
          Click a plan to learn more. Every plan is backed by a 30-day money-back guarantee.
        </p>
        <ul className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {props.plans.map((plan) => {
            // Use EFFECTIVE plan for the "Current" badge so admin overrides
            // and dunning downgrades show the right card as current.
            const isCurrent = plan.code === props.effectivePlanCode;
            const isActive = pending && activePlan === plan.code;
            // Plan-switch via Stripe Portal: when the user has an active
            // paid sub, a fresh Checkout would create a SECOND
            // subscription, which is wrong. Smoke #3 (2026-05-19): rather
            // than silently disabling the button, KEEP the button clickable
            // and open a modal pointing the user at Manage Subscription so
            // they understand the path. The H-02 server-side guard still
            // refuses a fresh Checkout call as defence-in-depth.
            const blockedByActiveSub = props.hasActiveSubscription;

            // Premium-style plan: no Stripe price, not coming soon.
            // Shows "Contact Us" button that links to the support page.
            const isContactUsPlan = !plan.comingSoon && !plan.hasStripePrice;

            const canChoose = !plan.comingSoon
              && !isCurrent
              && !isContactUsPlan
              && plan.hasStripePrice;

            const buttonLabel = isActive
              ? 'Redirecting…'
              : plan.comingSoon
              ? 'Coming soon'
              : isCurrent
              ? 'Your current plan'
              : isContactUsPlan
              ? 'Contact Us'
              : blockedByActiveSub && plan.hasStripePrice
              ? `Switch to ${plan.displayName}`
              : plan.hasStripePrice
              ? `Choose ${plan.displayName}`
              : 'Not yet available';

            return (
              <li
                key={plan.code}
                className={`rounded-lg border p-3 md:p-4 flex flex-col justify-between ${
                  plan.comingSoon
                    ? 'border-slate-200 bg-slate-50'
                    : isCurrent
                    ? 'border-emerald-300 bg-emerald-50'
                    : 'border-slate-200 bg-white'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between">
                    <p className="text-sm font-semibold text-slate-900">{plan.displayName}</p>
                    {plan.comingSoon && (
                      <span className="text-[10px] uppercase tracking-wide bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded-full font-semibold">
                        Coming soon
                      </span>
                    )}
                    {isCurrent && !plan.comingSoon && (
                      <span className="text-[10px] uppercase tracking-wide bg-emerald-600 text-white px-1.5 py-0.5 rounded-full font-semibold">
                        Current
                      </span>
                    )}
                  </div>
                  <p className="text-lg font-semibold text-slate-900 mt-1 flex items-baseline gap-2">
                    <span>
                      {plan.comingSoon ? '-' : formatPrice(plan.priceCentsMonthly)}
                    </span>
                    {!plan.comingSoon && (() => {
                      const original = formatOriginalPrice(plan.priceCentsMonthlyOriginal, plan.priceCentsMonthly);
                      return original ? (
                        <span className="text-sm font-medium text-slate-400 line-through">
                          {original}
                        </span>
                      ) : null;
                    })()}
                  </p>
                  {plan.tagline && (
                    <p className="text-xs text-slate-500 mt-1 italic">{plan.tagline}</p>
                  )}
                  <ul className="mt-2 space-y-1 text-xs text-slate-600">
                    <li>
                      {plan.comingSoon
                        ? 'Higher caps + extra features'
                        : `${plan.monthlyQuoteLimit} quotes / month`}
                    </li>
                    <li>
                      {plan.comingSoon ? 'More storage' : `${formatBytes(plan.storageLimitBytes)} storage`}
                    </li>
                    {!plan.comingSoon && plan.aiAssistPointsLimit !== null && plan.aiAssistPointsLimit > 0 && (
                      <li>{plan.aiAssistPointsLimit} AI Assist scan points</li>
                    )}
                    {!plan.comingSoon && (plan.monthlyAiParseLimit === null || plan.monthlyAiParseLimit > 0) && (
                      <li>{plan.monthlyAiParseLimit === null ? 'Unlimited' : plan.monthlyAiParseLimit} AI doc parses</li>
                    )}
                  </ul>
                </div>
                <div className="mt-3 flex gap-2">
                  <button
                    type="button"
                    onClick={() => setViewPlan(plan)}
                    className="flex-1 px-3 py-2 text-sm font-medium rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50"
                  >
                    View
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      // Active subscriber switching tiers -> in-app change flow
                      // (upgrade/downgrade via subscriptions.update), NOT the
                      // cancel-only Portal. Fresh subscribers -> Checkout.
                      if (blockedByActiveSub) {
                        setChangeTarget(plan);
                        return;
                      }
                      onChoose(plan);
                    }}
                    disabled={(!canChoose && !blockedByActiveSub && !isContactUsPlan) || pending}
                    title={
                      blockedByActiveSub
                        ? 'You already have an active subscription - click to manage.'
                        : plan.comingSoon
                        ? 'This tier is not available yet.'
                        : isCurrent
                        ? 'You are already on this plan.'
                        : isContactUsPlan
                        ? 'Contact us to learn more about this plan.'
                        : !plan.hasStripePrice
                        ? 'This plan is not yet configured in Stripe for this environment.'
                        : undefined
                    }
                    className={`flex-1 px-3 py-2 text-sm font-medium rounded-lg disabled:opacity-50 disabled:cursor-not-allowed ${
                      isContactUsPlan
                        ? 'bg-black text-white hover:bg-slate-800'
                        : 'bg-orange-600 text-white hover:bg-orange-700'
                    }`}
                  >
                    {buttonLabel}
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      </div>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-2 md:p-4 text-sm text-red-800">
          {error}
        </div>
      )}

      {/* In-app plan change confirm modal (upgrade now / downgrade at period end). */}
      {changeTarget && (
        <div
          className="fixed inset-0 backdrop-blur-sm bg-black/40 flex items-center justify-center z-50"
          role="dialog"
          aria-modal="true"
          aria-labelledby="change-modal-title"

        >
          <div className="bg-white rounded-2xl p-4 md:p-6 max-w-md w-full mx-4 shadow-xl">
            <h3 id="change-modal-title" className="text-lg font-semibold text-slate-900">
              {isUpgradeTarget ? 'Upgrade' : 'Switch'} to {changeTarget.displayName}?
            </h3>
            <p className="text-sm text-slate-600 mt-2">
              You&apos;ll move to{' '}
              <span className="font-medium text-slate-900">{changeTarget.displayName}</span> at{' '}
              <span className="font-medium text-slate-900">{formatPrice(changeTarget.priceCentsMonthly)}</span>
              {(() => {
                const original = formatOriginalPrice(
                  changeTarget.priceCentsMonthlyOriginal,
                  changeTarget.priceCentsMonthly,
                );
                return original ? <span className="text-slate-400 line-through ml-1">{original}</span> : null;
              })()}
              .
            </p>
            <p className="text-xs text-slate-500 mt-2">
              {isUpgradeTarget
                ? 'The change takes effect immediately. We\u2019ll prorate the difference for the rest of your current billing period and charge your card on file.'
                : 'You keep your current plan until the end of this billing period, then it switches to the new plan automatically. No charge or credit now.'}
            </p>
            {error && <p className="text-sm text-red-600 mt-3">{error}</p>}
            <div className="mt-5 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setChangeTarget(null)}
                disabled={pending}
                className="px-4 py-2 text-sm font-medium rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50 disabled:opacity-50 min-h-[44px]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => onConfirmChange(changeTarget)}
                disabled={pending}
                className="px-4 py-2 text-sm font-medium rounded-lg bg-orange-600 text-white hover:bg-orange-700 disabled:opacity-50"
              >
                {pending
                  ? 'Working\u2026'
                  : isUpgradeTarget
                  ? `Upgrade to ${changeTarget.displayName}`
                  : `Switch to ${changeTarget.displayName}`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Plan modal */}
      {viewPlan && (
        <div
          className="fixed inset-0 backdrop-blur-sm bg-black/40 flex items-center justify-center z-50"
          role="dialog"
          aria-modal="true"
          aria-labelledby="plan-modal-title"

        >
          <div className="bg-white rounded-2xl p-4 md:p-6 max-w-md w-full mx-4 shadow-xl">
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0">
                <h3 id="plan-modal-title" className="text-lg font-semibold text-slate-900">
                  {viewPlan.displayName}
                </h3>
                {viewPlan.tagline && (
                  <p className="text-sm text-slate-500 mt-1">{viewPlan.tagline}</p>
                )}
                <p className="text-xl font-semibold text-slate-900 mt-3 flex items-baseline gap-2">
                  <span>
                    {viewPlan.comingSoon
                      ? 'Pricing soon'
                      : formatPrice(viewPlan.priceCentsMonthly)}
                  </span>
                  {!viewPlan.comingSoon && (() => {
                    const original = formatOriginalPrice(viewPlan.priceCentsMonthlyOriginal, viewPlan.priceCentsMonthly);
                    return original ? (
                      <span className="text-base font-medium text-slate-400 line-through">
                        {original}
                      </span>
                    ) : null;
                  })()}
                </p>
              </div>
              {viewPlan.comingSoon && (
                <span className="text-[10px] uppercase tracking-wide bg-slate-200 text-slate-600 px-1.5 py-0.5 rounded-full font-semibold whitespace-nowrap">
                  Coming soon
                </span>
              )}
            </div>

            {/* Numeric caps grid */}
            <dl className="mt-5 grid grid-cols-2 gap-3 text-sm border-t border-slate-200 pt-4">
              <div>
                <dt className="text-xs text-slate-500">Quotes / month</dt>
                <dd className="font-semibold text-slate-900">
                  {viewPlan.comingSoon ? 'Higher' : viewPlan.monthlyQuoteLimit}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-slate-500">Storage</dt>
                <dd className="font-semibold text-slate-900">
                  {viewPlan.comingSoon ? 'More' : formatBytes(viewPlan.storageLimitBytes)}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-slate-500">Components</dt>
                <dd className="font-semibold text-slate-900">{formatCap(viewPlan.componentLimit)}</dd>
              </div>
              <div>
                <dt className="text-xs text-slate-500">Drawings &amp; Images</dt>
                <dd className={`font-semibold ${viewPlan.features.flashings ? 'text-slate-900' : 'text-slate-400 italic'}`}>
                  {viewPlan.features.flashings ? formatCap(viewPlan.flashingLimit) : 'Not included'}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-slate-500">Orders / mo</dt>
                <dd className={`font-semibold ${viewPlan.features.material_orders ? 'text-slate-900' : 'text-slate-400 italic'}`}>
                  {viewPlan.features.material_orders ? formatCap(viewPlan.monthlyMaterialOrderLimit) : 'Not included'}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-slate-500">Invoices / mo</dt>
                <dd className={`font-semibold ${viewPlan.features.invoices ? 'text-slate-900' : 'text-slate-400 italic'}`}>
                  {viewPlan.features.invoices ? formatCap(viewPlan.monthlyInvoiceLimit) : 'Not included'}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-slate-500">AI assistant / mo</dt>
                <dd className="font-semibold text-slate-900">
                  {viewPlan.monthlyAiTokens === null
                    ? 'Unlimited'
                    : `${(viewPlan.monthlyAiTokens / 1_000_000).toLocaleString(undefined, { maximumFractionDigits: 1 })}M tokens`}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-slate-500">Included seats</dt>
                <dd className="font-semibold text-slate-900">{viewPlan.includedSeats}</dd>
              </div>
              <div>
                <dt className="text-xs text-slate-500">AI Assist scans</dt>
                <dd className={`font-semibold ${viewPlan.aiAssistPointsLimit !== null && viewPlan.aiAssistPointsLimit > 0 ? 'text-slate-900' : 'text-slate-400 italic'}`}>
                  {viewPlan.aiAssistPointsLimit !== null && viewPlan.aiAssistPointsLimit > 0
                    ? `${viewPlan.aiAssistPointsLimit} points`
                    : 'Not included'}
                </dd>
              </div>
              <div>
                <dt className="text-xs text-slate-500">AI doc parses / mo</dt>
                <dd className={`font-semibold ${viewPlan.monthlyAiParseLimit === null || viewPlan.monthlyAiParseLimit > 0 ? 'text-slate-900' : 'text-slate-400 italic'}`}>
                  {viewPlan.monthlyAiParseLimit === null
                    ? 'Unlimited'
                    : viewPlan.monthlyAiParseLimit === 0
                      ? 'Not included'
                      : `${viewPlan.monthlyAiParseLimit} parses`}
                </dd>
              </div>
            </dl>

            {/* Feature flags */}
            <ul className="mt-4 space-y-1.5 text-sm border-t border-slate-200 pt-4">
              <FeatureRow label="Digital measuring" included={viewPlan.features.digital_takeoff} />
              <FeatureRow label="Drawings & Images" included={viewPlan.features.flashings} />
              <FeatureRow label="Orders" included={viewPlan.features.material_orders} />
              <FeatureRow label="Invoices" included={viewPlan.features.invoices} />
              <FeatureRow label="Message Center" included={viewPlan.features.message_center} />
              <FeatureRow label="Automated follow-ups" included={viewPlan.features.followups} />
              <FeatureRow label="Send quotes by email" included={viewPlan.features.email_send} />
              <FeatureRow label="Activity card" included={viewPlan.features.activity_card} />
              <FeatureRow label="AI Assist scan points (Roofing only)" included={viewPlan.aiAssistPointsLimit !== null && viewPlan.aiAssistPointsLimit > 0} extra={viewPlan.aiAssistPointsLimit !== null && viewPlan.aiAssistPointsLimit > 0 ? `${viewPlan.aiAssistPointsLimit} points` : undefined} />
              <FeatureRow label="AI document parsing (quotes, orders, invoices)" included={viewPlan.monthlyAiParseLimit === null || viewPlan.monthlyAiParseLimit > 0} extra={viewPlan.monthlyAiParseLimit !== null && viewPlan.monthlyAiParseLimit > 0 ? `${viewPlan.monthlyAiParseLimit} / mo` : viewPlan.monthlyAiParseLimit === null ? 'Unlimited' : undefined} />
            </ul>

            {/* Marketing blurbs */}
            {viewPlan.featureBlurbs.length > 0 && (
              <ul className="mt-4 space-y-1.5 text-sm text-slate-600 border-t border-slate-200 pt-4">
                {viewPlan.featureBlurbs.map((blurb, i) => (
                  <li key={i} className="flex gap-2 items-start">
                    <svg className="w-4 h-4 mt-0.5 text-orange-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                    <span>{blurb}</span>
                  </li>
                ))}
              </ul>
            )}

            <div className="flex gap-3 justify-end mt-6">
              <button
                type="button"
                onClick={() => setViewPlan(null)}
                className="px-4 py-2 text-sm font-medium rounded-full text-slate-700 hover:bg-slate-100"
              >
                Close
              </button>
              {(() => {
                // Mirror the plan-card button logic so the View modal can
                // ALSO upgrade/downgrade. Active subscribers go through the
                // in-app change flow (subscriptions.update via the confirm
                // modal); fresh subscribers go through Checkout (onChoose).
                const vBlockedByActiveSub = props.hasActiveSubscription;
                const vIsCurrent = viewPlan.code === props.effectivePlanCode;
                const vIsContactUsPlan = !viewPlan.comingSoon && !viewPlan.hasStripePrice;
                const vCanAct =
                  !viewPlan.comingSoon
                  && !vIsCurrent
                  && !vIsContactUsPlan
                  && !pending
                  && viewPlan.hasStripePrice;
                const vIsUpgrade =
                  currentSortOrder != null ? viewPlan.sortOrder > currentSortOrder : true;
                return (
                  <button
                    type="button"
                    onClick={() => {
                      if (vIsContactUsPlan) {
                        const slug = typeof window !== 'undefined' ? window.location.pathname.split('/')[1] : '';
                        window.location.href = `/${slug}/account?tab=support`;
                        return;
                      }
                      if (vBlockedByActiveSub) {
                        // In-app tier change: hand off to the confirm modal.
                        setViewPlan(null);
                        setChangeTarget(viewPlan);
                        return;
                      }
                      onChoose(viewPlan);
                    }}
                    disabled={!vCanAct && !vBlockedByActiveSub && !vIsContactUsPlan}
                    title={
                      viewPlan.comingSoon
                        ? 'This tier is not available yet.'
                        : vIsCurrent
                        ? 'You are already on this plan.'
                        : vIsContactUsPlan
                        ? 'Contact us to learn more about this plan.'
                        : !viewPlan.hasStripePrice
                        ? 'This plan is not yet configured in Stripe for this environment.'
                        : undefined
                    }
                    className={`px-4 py-2 text-sm font-medium rounded-full disabled:opacity-50 disabled:cursor-not-allowed text-white ${
                      vIsContactUsPlan
                        ? 'bg-black hover:bg-slate-800'
                        : 'bg-orange-600 hover:bg-orange-700'
                    }`}
                  >
                    {viewPlan.comingSoon
                      ? 'Coming soon'
                      : vIsCurrent
                      ? 'Current plan'
                      : vIsContactUsPlan
                      ? 'Contact Us'
                      : vBlockedByActiveSub
                      ? (vIsUpgrade ? `Upgrade to ${viewPlan.displayName}` : `Switch to ${viewPlan.displayName}`)
                      : 'Purchase'}
                  </button>
                );
              })()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * Single row in the feature-flag list inside the View modal. Renders a
 * checkmark or cross depending on `included`. Optional `extra` text shown
 * after the label (e.g. "50 points").
 */
function FeatureRow({ label, included, extra }: { label: string; included: boolean; extra?: string }) {
  return (
    <li className="flex items-center gap-2">
      {included ? (
        <svg className="w-4 h-4 text-emerald-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
        </svg>
      ) : (
        <svg className="w-4 h-4 text-slate-300 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      )}
      <span className={`${included ? 'text-slate-900' : 'text-slate-400'}`}>{label}{extra && included ? <span className="text-slate-500 font-medium ml-1">- {extra}</span> : null}</span>
    </li>
  );
}
