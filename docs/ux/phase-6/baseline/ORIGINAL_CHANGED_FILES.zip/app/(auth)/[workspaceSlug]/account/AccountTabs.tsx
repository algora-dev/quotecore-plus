'use client';

import { useState, useEffect, useCallback, type ReactNode } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

/**
 * Tabbed wrapper for the Account section.
 *
 * The whole /account experience is a single client-rendered tab switcher.
 * Server-loaded data for every tab is fetched once at the parent page
 * (`page.tsx`) and passed in via props \u2014 switching between Profile / Company /
 * Security / Notifications / Billing / Support is a state change, not a route
 * change. This is the speed win Shaun asked for: no server round-trip on tab
 * navigation.
 *
 * Deep links still work via the `?tab=` URL parameter:
 *   - /account                   -> Profile (default)
 *   - /account?tab=company       -> Company
 *   - /account?tab=security      -> Security
 *   - /account?tab=notifications -> Q Assistant
 *   - /account?tab=billing       -> Billing
 *   - /account?tab=support       -> Support tickets
 *
 * Old routes (/account/company, /account/security, etc.) redirect to the new
 * tab URLs via small server-component shims in their existing folders.\n */

export type AccountTabKey =
  | 'profile'
  | 'company'
  | 'security'
  | 'notifications'
  | 'billing'
  | 'integrations'
  | 'support';

/**
 * Tab descriptor. `disabled` items are rendered but un-clickable; we use
 * this for the Team tab today (multi-user support not yet built). The
 * disabled item is NOT a member of `AccountTabKey` because it never becomes
 * the active tab - typing `?tab=team` resolves to `profile` instead.
 */
type Tab =
  | { key: AccountTabKey; label: string; icon: ReactNode; disabled?: false }
  | { key: string; label: string; icon: ReactNode; disabled: true; disabledTitle: string };

const TABS: Tab[] = [
  {
    key: 'profile',
    label: 'Account',
    icon: (
      <svg className="w-[18px] h-[18px] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
      </svg>
    ),
  },
  {
    key: 'company',
    label: 'Company',
    icon: (
      <svg className="w-[18px] h-[18px] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 21h18M5 21V7l7-4 7 4v14M9 12h.01M15 12h.01M9 16h.01M15 16h.01" />
      </svg>
    ),
  },
  {
    key: 'security',
    label: 'Security',
    icon: (
      <svg className="w-[18px] h-[18px] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m0 0v2m0-2h2m-2 0h-2m6-6V7a4 4 0 00-8 0v4M5 11h14a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2z" />
      </svg>
    ),
  },
  {
    key: 'notifications',
    label: 'Q Assistant',
    icon: (
      <svg className="w-[18px] h-[18px] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0a3 3 0 11-6 0" />
      </svg>
    ),
  },
  {
    key: 'billing',
    label: 'Billing',
    icon: (
      <svg className="w-[18px] h-[18px] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 10h18M5 6h14a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2z" />
      </svg>
    ),
  },
  {
    key: 'support',
    label: 'Support',
    icon: (
      <svg className="w-[18px] h-[18px] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
      </svg>
    ),
  },
  {
    key: 'integrations',
    label: 'Integrations',
    icon: (
      <svg className="w-[18px] h-[18px] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
      </svg>
    ),
  },
  {
    // Placeholder for multi-user support. Renders as a disabled row with a
    // "soon" pill so users know more is coming without us implying it ships
    // imminently. Restored after a brief disappearance during the tabs
    // refactor (Shaun, 2026-05-11).
    key: 'team',
    label: 'Team',
    disabled: true,
    disabledTitle: 'Coming soon',
    icon: (
      <svg className="w-[18px] h-[18px] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-5.13a4 4 0 110-8 4 4 0 010 8zm6 4a3 3 0 100-6 3 3 0 000 6zM5 14a3 3 0 100-6 3 3 0 000 6z" />
      </svg>
    ),
  },
];

function readTabFromUrl(value: string | null): AccountTabKey {
  switch (value) {
    case 'company':
    case 'security':
    case 'notifications':
    case 'billing':
    case 'integrations':
    case 'support':
      return value;
    case 'profile':
    default:
      return 'profile';
  }
}

interface AccountTabsProps {
  /** Pre-rendered server content for each tab. */
  panels: Record<AccountTabKey, ReactNode>;
}

export function AccountTabs({ panels }: AccountTabsProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const initial = readTabFromUrl(searchParams.get('tab'));
  const [active, setActive] = useState<AccountTabKey>(initial);

  // Keep state in sync with the URL when the user navigates back/forward or
  // when an external link sets `?tab=...`. React 19's stricter rule warns
  // about setState inside effects - here the URL is an external source we
  // intentionally mirror into local state. The set is guarded against
  // redundant updates so it doesn't loop.
  useEffect(() => {
    const next = readTabFromUrl(searchParams.get('tab'));
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setActive((prev) => (prev === next ? prev : next));
  }, [searchParams]);

  const pickTab = useCallback(
    (key: AccountTabKey) => {
      setActive(key);
      // Replace state (no history entry per click) so the back button still
      // takes the user out of /account in a single press.
      const params = new URLSearchParams(searchParams);
      if (key === 'profile') params.delete('tab');
      else params.set('tab', key);
      const qs = params.toString();
      router.replace(qs ? `?${qs}` : '?', { scroll: false });
    },
    [router, searchParams],
  );

  return (
    <div className="flex flex-col md:flex-row md:items-start gap-6">
      <aside className="w-full md:w-56 lg:w-60 md:flex-shrink-0">
        <nav aria-label="Account sections" className="md:sticky md:top-6 md:self-start">
          <ul className="flex md:flex-col gap-1 overflow-x-auto md:overflow-visible -mx-2 md:mx-0 px-0 md:px-0 pb-2 md:pb-0">
            {TABS.map((tab) => {
              if (tab.disabled) {
                return (
                  <li key={tab.key}>
                    <div
                      title={tab.disabledTitle}
                      aria-disabled="true"
                      className="flex w-full items-center gap-2.5 px-3 py-2.5 md:py-2 rounded-lg text-sm font-medium text-slate-400 cursor-not-allowed select-none whitespace-nowrap md:whitespace-normal min-h-[44px] md:min-h-0"
                    >
                      {tab.icon}
                      <span>{tab.label}</span>
                      <span className="ml-auto text-[10px] uppercase tracking-wide font-semibold text-slate-400 bg-slate-100 rounded-full px-1.5 py-0.5">
                        soon
                      </span>
                    </div>
                  </li>
                );
              }
              const isActive = active === tab.key;
              return (
                <li key={tab.key}>
                  <button
                    type="button"
                    onClick={() => pickTab(tab.key as AccountTabKey)}
                    aria-current={isActive ? 'page' : undefined}
                    className={`flex w-full items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition whitespace-nowrap md:whitespace-normal text-left ${
                      isActive
                        ? 'bg-orange-50 text-orange-700'
                        : 'text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {tab.icon}
                    <span>{tab.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>
      </aside>
      <main className="flex-1 min-w-0">{panels[active]}</main>
    </div>
  );
}
